import sys
import math
import pandas as pd
from .topsis_101703557 import *
if __name__=="__main__":
    main()
