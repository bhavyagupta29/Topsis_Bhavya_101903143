This package is implementation of topsis technique of multi-criteria decision analysis.
This package will accept three parameters:
1. data.csv //file which contains the models and parameters
2. string of weights separated by commas(,)
3. string of requirements (+/-) separated by commas(,)
// important
install pandas,sys,operator and math libraries before installing this
//
You can install this package using following command
pip install topsis-101703557
